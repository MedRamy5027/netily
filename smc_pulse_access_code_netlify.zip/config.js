/* Admin setup: set the public HTTPS URL of the secured SMC bridge once here.
   This is an address, not a secret. Never put the access code or API token in this file. */
window.SMC_PULSE_CONFIG = {
  apiBaseUrl: "" // Example: "https://smc-bridge.your-company-domain.com"
};
